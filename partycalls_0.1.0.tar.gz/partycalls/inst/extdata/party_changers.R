icpsrLegis,mc,party,bioguide_id
14240,JEFFORDS (R VT),R,J000072
94240,JEFFORDS (Indep VT),Indep,J000072